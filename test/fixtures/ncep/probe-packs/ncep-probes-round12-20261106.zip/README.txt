Round 12 (2700–2744): end-cut isolation, L6 etch forms, etch position, M-39

- 2700–2706 M-43: control, standard, real section, real trims, both, real start, real end
- 2710–2716 M-51: same matrix
- 2720–2724 M-39: control, standard, real section, real trims, both
- 2730–2736 M-3 etch: control, L6 rect/line/outline/needSetAdobe/T/text-L4
- 2740–2744 M-1 position: control, NC position, exemplar y3306, centre, exemplar bar
- 2750–2751 quantity 2; 2752–2758 text layer/angle/size; 2759–2760 flipFlanges;
  2761–2762 empty holes / empty marks

Also includes round 11 (bar orientation / exemplar controls):
- 2500/2501 real PFC/UB corrected-marking exemplars, renamed only; 2502/2503 layer-6 controls
- 2600 M-3 control; 2601/2602 L6 negative-x no-transform Segment 1/3;
  2603/2604 L4 negative-x no-transform Segment 1/3;
  2605/2606 L4 positive-x rotate(180) Segment 3/1; 2607 L6 positive-x rotate(180) Segment 3

## Matrix
| File | CadRoot Name | Variant | Errors | Warnings |
| --- | --- | --- | --- | --- |
| 2700 M-43 control.ncep | M-43 | real control | ok | ok |
| 2701 M-43 standard.ncep | 2701 M-43 standard | standard | ok | ok |
| 2702 M-43 real section.ncep | 2702 M-43 real section | real section | ok | ok |
| 2703 M-43 real trims.ncep | 2703 M-43 real trims | real trims | ok | ok |
| 2704 M-43 real section trims.ncep | 2704 M-43 real section trims | real section trims | ok | ok |
| 2705 M-43 real start.ncep | 2705 M-43 real start | real start | ok | ok |
| 2706 M-43 real end.ncep | 2706 M-43 real end | real end | ok | ok |
| 2710 M-51 control.ncep | M-51 | real control | ok | ok |
| 2711 M-51 standard.ncep | 2711 M-51 standard | standard | ok | ok |
| 2712 M-51 real section.ncep | 2712 M-51 real section | real section | ok | ok |
| 2713 M-51 real trims.ncep | 2713 M-51 real trims | real trims | ok | ok |
| 2714 M-51 real section trims.ncep | 2714 M-51 real section trims | real section trims | ok | ok |
| 2715 M-51 real start.ncep | 2715 M-51 real start | real start | ok | ok |
| 2716 M-51 real end.ncep | 2716 M-51 real end | real end | ok | ok |
| 2720 M-39 control.ncep | M-39 | real control | ok | ok |
| 2721 M-39 standard.ncep | 2721 M-39 standard | standard | ok | ok |
| 2722 M-39 real section.ncep | 2722 M-39 real section | real section | ok | ok |
| 2723 M-39 real trims.ncep | 2723 M-39 real trims | real trims | ok | ok |
| 2724 M-39 real section trims.ncep | 2724 M-39 real section trims | real section trims | ok | ok |
| 2730 M-3 control.ncep | M-3 | real control | ok | ok |
| 2731 M-3 L6 rect.ncep | 2731 M-3 L6 rect | L6 rect | ok | ok |
| 2732 M-3 L6 line.ncep | 2732 M-3 L6 line | L6 line | ok | ok |
| 2733 M-3 L6 outline.ncep | 2733 M-3 L6 outline | L6 outline | ok | ok |
| 2734 M-3 L6 rect needSetAdobe.ncep | 2734 M-3 L6 rect needSetAdobe | L6 rect needSetAdobe | ok | ok |
| 2735 M-3 L6 rect T.ncep | 2735 M-3 L6 rect T | L6 rect T | ok | ok |
| 2736 M-3 L6 text L4.ncep | 2736 M-3 L6 text L4 | L6 text L4 | ok | ok |
| 2740 M-1 control.ncep | M-1 | real control | ok | ok |
| 2741 M-1 NC position.ncep | 2741 M-1 NC position | NC position | ok | ok |
| 2742 M-1 exemplar y3306.ncep | 2742 M-1 exemplar y3306 | exemplar y3306 | ok | ok |
| 2743 M-1 centre position.ncep | 2743 M-1 centre position | centre position | ok | ok |
| 2744 M-1 exemplar bar.ncep | 2744 M-1 exemplar bar | exemplar bar | ok | ok |
| 2750 M-3 quantity2.ncep | 2750 M-3 quantity2 | quantity 2 | ok | ok |
| 2751 M-1 quantity2.ncep | 2751 M-1 quantity2 | quantity 2 | ok | ok |
| 2752 M-3 text L6 0.ncep | 2752 M-3 text L6 0 | text L6 0 | ok | mark-mismatch |
| 2753 M-3 text L4 0.ncep | 2753 M-3 text L4 0 | text L4 0 | ok | ok |
| 2754 M-3 text L6 45.ncep | 2754 M-3 text L6 45 | text L6 45 | ok | mark-mismatch |
| 2755 M-3 text L6 90.ncep | 2755 M-3 text L6 90 | text L6 90 | ok | mark-mismatch |
| 2756 M-3 text L6 180.ncep | 2756 M-3 text L6 180 | text L6 180 | ok | mark-mismatch |
| 2757 M-3 text L6 size20.ncep | 2757 M-3 text L6 size20 | text L6 size20 | ok | mark-mismatch |
| 2758 M-3 text L6 size60.ncep | 2758 M-3 text L6 size60 | text L6 size60 | ok | mark-mismatch |
| 2759 M-1 flipFlanges.ncep | 2759 M-1 flipFlanges | flipFlanges | ok | ok |
| 2760 M-3 flipFlanges.ncep | 2760 M-3 flipFlanges | flipFlanges | ok | ok |
| 2761 M-3 no holes.ncep | 2761 M-3 no holes | no holes | ok | ok |
| 2762 M-3 no marks.ncep | 2762 M-3 no marks | no marks | ok | ok |
